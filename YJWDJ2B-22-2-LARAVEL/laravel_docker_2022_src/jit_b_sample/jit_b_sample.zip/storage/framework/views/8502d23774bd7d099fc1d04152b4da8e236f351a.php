<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>회원가입페이지</title>
</head>
<body>
    <h1>사용자등록폼</h1>
    <ul>
        <?php if(count($errors)>0): ?> 
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($err); ?></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </ul>
    <!-- <form name='registform' action="/register" method='post' id='registform'> -->
    <form name='registform' action="/uregist" method='post' id='registform'>
        <?php echo e(csrf_field()); ?> 
        <!-- <?php echo csrf_field(); ?> -->
        <dl>
            <dt>이름:</dt>
            <dd>
                <input type="text" name='name' size='30'>
                <span><?php echo e($errors->first('name')); ?></span>
            </dd>
        </dl>
        <dl>
            <dt>메일주소:</dt>
            <dd>
                <input type="text" name='email' size='30'>
                <span><?php echo e($errors->first('email')); ?></span>
            </dd>
        </dl>
        <dl>
            <dt>비밀번호:</dt>
            <dd>
                <input type="password" name='password' size='30'>
                <span><?php echo e($errors->first('password')); ?></span>
            </dd>
        </dl>
        <dl>
            <dt>비밀번호(확인):</dt>
            <dd>
            <input type="password" name='password_confirmation' size='30'>
                <span><?php echo e($errors->first('password_confirmation')); ?></span>
            </dd>
        </dl>
        <button type='submit' name='action' vaule='send'>보내기</button>
    </form>
</body>
</html><?php /**PATH /var/www/html/resources/views/regist/register.blade.php ENDPATH**/ ?>